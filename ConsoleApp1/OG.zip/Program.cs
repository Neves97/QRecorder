﻿using GravadorBandejaSilencioso;
using System;
using System.Drawing;
using System.Windows.Forms;

class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        // passo zero, edite o arquivo .csproj e mude o OutputType para WinExe, isso é importante para não abrir a janela de console junto com o ícone

        using var gravador = new GerenciadorAudio();

        //criar menu
        ContextMenuStrip menuFlutuante = new ContextMenuStrip();
        // Sintaxe: new ToolStripMenuItem("Texto que aparece", Ícone, Método_Que_Será_Executado)
        ToolStripMenuItem botaoSair = new ToolStripMenuItem("Sair do Programa");
        ToolStripMenuItem botaoGravar = new ToolStripMenuItem("Iniciar Gravação", null, (s, e) =>
        {
            var botao = s as ToolStripMenuItem;
            if (botao == null) return;

            // Deixa a classe decidir o que fazer com base no estado interno dela
            if (!gravador.EstaGravando)
            {
                gravador.Iniciar();
                botao.Text = "Parar Gravação";
            }
            else
            {
                gravador.Parar();
                botao.Text = "Iniciar Gravação";
            }
        });

        //associar
        menuFlutuante.Items.Add(botaoGravar);
        menuFlutuante.Items.Add(new ToolStripSeparator());
        menuFlutuante.Items.Add(botaoSair);


        //  criar icone e assosciar os menus
        NotifyIcon icone = new NotifyIcon();
      
        icone.Icon = SystemIcons.WinLogo;
        icone.Text = "Gravador do Meu Amigo";
        icone.Visible = true;
        icone.ContextMenuStrip = menuFlutuante;
       

        // 2. Dispara o balão
        icone.ShowBalloonTip(3000, "Status", "Estou rodando de verdade!", ToolTipIcon.Warning);


        // 3. OBRIGATÓRIO: Isola a thread e impede o programa de fechar
        Application.Run();
    }

  
}