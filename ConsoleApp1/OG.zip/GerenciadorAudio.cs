﻿using System;
using System.IO;
using NAudio.Wave;

namespace GravadorBandejaSilencioso
{
    public class GerenciadorAudio : IDisposable
    {
        private WaveInEvent? _waveIn;
        private WaveFileWriter? _writer;

        // Propriedade pública para a interface/bandeja consultar o estado atual
        public bool EstaGravando { get; private set; } = false;

        public void Iniciar()
        {
            if (EstaGravando) return;

            _waveIn = new WaveInEvent();
            _waveIn.WaveFormat = new WaveFormat(44100, 1); // 44.1kHz, Mono

            string pastaMusicas = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic);

            string nomeArquivo = $"gravacao_{DateTime.Now:yyyyMMdd_HHmmss}.wav";

            // 2. Combina a pasta com o nome do arquivo de forma segura
            string caminhoCompleto = Path.Combine(pastaMusicas, nomeArquivo);
            
            _writer = new WaveFileWriter(caminhoCompleto, _waveIn.WaveFormat);

            // Vincula o recebimento de bytes ao arquivo em disco
            _waveIn.DataAvailable += (s, e) =>
            {
                _writer?.Write(e.Buffer, 0, e.BytesRecorded);
            };

            // Vincula o encerramento físico à limpeza dos ponteiros
            _waveIn.RecordingStopped += (s, e) =>
            {
                LimparRecursos();
            };

            _waveIn.StartRecording();
            EstaGravando = true;
        }

        public void Parar()
        {
            if (!EstaGravando) return;

            // Solicita a parada ao hardware. O evento 'RecordingStopped' cuidará do Dispose
            _waveIn?.StopRecording();
            EstaGravando = false;
        }

        private void LimparRecursos()
        {
            _writer?.Dispose();
            _writer = null;
            _waveIn?.Dispose();
            _waveIn = null;
        }

        public void Dispose()
        {
            // Garante que o arquivo feche se o objeto for destruído inesperadamente
            if (EstaGravando)
            {
                Parar();
            }
            else
            {
                LimparRecursos();
            }
        }
    }
}